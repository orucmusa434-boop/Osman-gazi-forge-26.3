package net.osmangazi;

import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.animal.equine.AbstractHorse;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

/** Alp / Moğol / Barbar atı. Eyer gerekmeden binilir (eyer otomatik takılır). */
public class OsmanHorse extends AbstractHorse {
    public record HorseDef(String id, UnitDef.Faction faction, String texture, String tameItem) {}

    public static final List<HorseDef> ALL = List.of(
        new HorseDef("alp_ati", UnitDef.Faction.ALP, "textures/entity/horse/horse_white.png", "minecraft:apple"),
        new HorseDef("mongol_ati", UnitDef.Faction.MONGOL, "textures/entity/horse/horse_chestnut.png", "minecraft:wheat"),
        new HorseDef("barbar_ati", UnitDef.Faction.BARBAR, "textures/entity/horse/horse_black.png", "minecraft:carrot"));

    private final HorseDef hdef;
    @Nullable private UUID ownerId;

    public OsmanHorse(EntityType<? extends AbstractHorse> type, Level level, HorseDef hdef) {
        super(type, level);
        this.hdef = hdef;
    }

    public HorseDef hdef() { return hdef; }

    public Identifier texture() { return Identifier.parse("minecraft:" + hdef.texture()); }

    public static net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder createAttributes() {
        return AbstractHorse.createBaseHorseAttributes()
            .add(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH, 40.0D)
            .add(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED, 0.3D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.2D) {
            @Override public boolean canUse() { return getFirstPassenger() == null && super.canUse(); }
        });
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.7D) {
            @Override public boolean canUse() { return getFirstPassenger() == null && super.canUse(); }
        });
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }

    @Nullable
    @Override
    public LivingEntity getControllingPassenger() {
        return getFirstPassenger() instanceof Player p ? p : null;
    }

    private boolean isTameItem(ItemStack s) {
        if (s.isEmpty()) return false;
        Identifier k = BuiltInRegistries.ITEM.getKey(s.getItem());
        return k != null && k.toString().equals(hdef.tameItem());
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!isTamed()) {
            if (isTameItem(stack)) {
                if (!level().isClientSide) {
                    if (!player.getAbilities().instabuild) stack.shrink(1);
                    if (random.nextFloat() < 0.5F) {
                        setTamed(true);
                        ownerId = player.getUUID();
                        setItemSlot(EquipmentSlot.SADDLE, new ItemStack(Items.SADDLE));
                        level().broadcastEntityEvent(this, (byte) 7);
                    } else level().broadcastEntityEvent(this, (byte) 6);
                }
                return InteractionResult.sidedSuccess(level().isClientSide);
            }
            return InteractionResult.PASS;
        }
        if (hand == InteractionHand.MAIN_HAND && stack.isEmpty() && !isVehicle() && !isBaby()
            && player.getUUID().equals(ownerId) && !player.isSecondaryUseActive()) {
            if (!level().isClientSide) player.startRiding(this);
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return InteractionResult.PASS;
    }

    @Override public boolean isFood(ItemStack s) { return false; }
    @Nullable @Override public AgeableMob getBreedOffspring(ServerLevel l, AgeableMob o) { return null; }
    @Override public boolean removeWhenFarAway(double d) { return !isTamed() && !isVehicle(); }
}
