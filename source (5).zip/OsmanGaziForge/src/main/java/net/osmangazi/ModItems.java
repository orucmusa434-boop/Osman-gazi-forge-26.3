package net.osmangazi;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.ArrowItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ToolMaterial;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, OsmanGaziMod.MODID);
    public static final List<RegistryObject<Item>> ALL = new ArrayList<>();
    public static final List<RegistryObject<Item>> EGGS = new ArrayList<>();
    public static final RegistryObject<Item> GULLE;

    private static Item.Properties props(String name) {
        return new Item.Properties().setId(ITEMS.key(name));
    }

    private static RegistryObject<Item> reg(String name, java.util.function.Function<Item.Properties, Item> f) {
        RegistryObject<Item> o = ITEMS.register(name, () -> f.apply(props(name)));
        ALL.add(o);
        return o;
    }

    private static void regEgg(String id) {
        EGGS.add(ITEMS.register(id + "_spawn_egg", () -> new SpawnEggItem(props(id + "_spawn_egg").spawnEgg(ModEntities.object(id).get()))));
    }

    private static void regHorseEgg(String id) {
        EGGS.add(ITEMS.register(id + "_spawn_egg", () -> new SpawnEggItem(props(id + "_spawn_egg").spawnEgg(ModEntities.horseObject(id).get()))));
    }

    static {
        // Balta / Kılıç / Kazma: malzeme ve hasar değerleri 1.20.1 sürümüyle aynı
        reg("alp_baltasi", p -> new Item(p.axe(ToolMaterial.IRON, 4.0F, -3.0F).durability(900)));
        reg("alp_cekici", p -> new Item(p.sword(ToolMaterial.IRON, 6, -3.0F).durability(1000)));
        reg("alp_kazmasi", p -> new Item(p.pickaxe(ToolMaterial.DIAMOND, 1, -2.8F).durability(900)));
        reg("alp_kilici", p -> new Item(p.sword(ToolMaterial.IRON, 5, -2.4F).durability(1000)));
        reg("alp_mizragi", p -> new Item(p.sword(ToolMaterial.IRON, 5, -2.8F).durability(900)));
        reg("alp_oku", p -> new ArrowItem(p));
        reg("alp_yayi", p -> new BowItem(p.durability(700)));
        reg("alpago_baltasi", p -> new Item(p.axe(ToolMaterial.IRON, 9.0F, -3.0F).durability(1500)));
        reg("barbar_baltasi", p -> new Item(p.axe(ToolMaterial.IRON, 5.0F, -3.0F).durability(900)));
        reg("barbar_cekici", p -> new Item(p.sword(ToolMaterial.IRON, 6, -3.0F).durability(1000)));
        reg("barbar_kazmasi", p -> new Item(p.pickaxe(ToolMaterial.IRON, 2, -2.8F).durability(900)));
        reg("barbar_mizragi", p -> new Item(p.sword(ToolMaterial.IRON, 5, -2.8F).durability(900)));
        reg("barbar_oku", p -> new ArrowItem(p));
        reg("barbar_yayi", p -> new BowItem(p.durability(700)));
        reg("kayi_bayragi", p -> new Item(p.stacksTo(16)));
        reg("kayi_kilici", p -> new Item(p.sword(ToolMaterial.IRON, 3, -2.4F).durability(600)));
        reg("lahmacun", p -> new LahmacunItem(p.food(new FoodProperties(16, 0.6F, true))));
        reg("mongol_cekici", p -> new Item(p.sword(ToolMaterial.IRON, 6, -3.0F).durability(850)));
        reg("mongol_kazmasi", p -> new Item(p.pickaxe(ToolMaterial.IRON, 2, -2.8F).durability(900)));
        reg("mongol_kilici", p -> new Item(p.sword(ToolMaterial.IRON, 4, -2.4F).durability(700)));
        reg("mongol_mizragi", p -> new Item(p.sword(ToolMaterial.IRON, 4, -2.8F).durability(750)));
        reg("mongol_oku", p -> new ArrowItem(p));
        reg("mongol_yayi", p -> new BowItem(p.durability(550)));
        reg("nayman_kilici", p -> new Item(p.sword(ToolMaterial.IRON, 9, -2.4F).durability(2200)));
        reg("osman_kilici", p -> new Item(p.sword(ToolMaterial.IRON, 6, -2.4F).durability(1800)));
        GULLE = reg("gulle", p -> new Item(p));
        reg("el_topu", p -> new HandCannonItem(p.durability(300)));
        for (UnitDef def : UnitDef.ALL) regEgg(def.id());
        for (OsmanHorse.HorseDef hd : OsmanHorse.ALL) regHorseEgg(hd.id());
    }
}
